# RiskWise Fraud Datasets — Data Dictionary

## fraud_transactions.csv
Transaction-level fraud features. No target label is included.
- `po_id`: existing procurement PO identifier — identifier.
- `supplier_id`: existing supplier identifier — identifier/foreign key.
- `transaction_date`: PO transaction date — historical/context.
- `total_amount`: PO total value — feature.
- `average_historical_po_value`: supplier prior average PO value — historical/context feature.
- `amount_deviation_percent`: current amount relative to supplier history — feature.
- `current_unit_price`: average current unit price for the PO's primary product — feature.
- `average_historical_unit_price`: supplier prior average unit price — historical/context feature.
- `market_price`: product/month market reference — historical/context feature.
- `price_deviation_from_market_percent`: current price vs market — feature.
- `quantity`: aggregate PO quantity — feature.
- `average_historical_quantity`: supplier prior average quantity — historical/context feature.
- `quantity_deviation_percent`: current quantity vs historical average — feature.
- `previous_po_count_30d`: prior supplier POs in 30 days — feature.
- `previous_po_value_30d`: prior supplier PO value in 30 days — feature.
- `similar_po_count_7d`: similar-product POs in prior 7 days — feature.
- `duplicate_similarity_flag`: near-duplicate signal — feature.
- `split_transaction_flag`: split-transaction signal — feature.
- `unusual_timing_flag`: unusual activity timing signal — feature.
- `supplier_inactive_days_before_po`: days since supplier's prior PO — historical/context feature.
- `bank_account_recently_changed`: recent bank change signal — feature.
- `address_recently_changed`: recent address change signal — feature.
- `contact_recently_changed`: recent phone/email change signal — feature.

## supplier_changes.csv
Synthetic supplier profile change events. Hash fields are synthetic and non-PII.
All fields are historical/context except `change_id` (identifier) and `supplier_id` (foreign-key identifier).

## payment_transactions.csv
Synthetic payment events tied to existing POs. `payment_id` is the identifier; `po_id` and `supplier_id` are foreign-key identifiers. Remaining fields are historical/context or derived features.

## fraud_labels.csv
Training target.
- `po_id`: identifier/foreign key.
- `fraud_label`: target label (0 legitimate, 1 suspicious/fraudulent).
- `fraud_type`: target category.
- `fraud_severity`: target severity.
- `fraud_reason`: target/explanation.

## fraud_test_cases.csv
Unseen feature cases for inference. Same feature schema as `fraud_transactions.csv`; no target label.

## fraud_ground_truth.csv
Expected results for `fraud_test_cases.csv`, generated independently from the model-training labels.
- `po_id`: test-case identifier.
- `expected_fraud_label`: evaluation target.
- `expected_fraud_level`: evaluation target.
- `expected_fraud_type`: evaluation target.
- `expected_primary_reasons`: evaluation explanation.

The first-engine datasets are not modified.
