# Generation Guide
Generated from the uploaded first-engine procurement dataset.

Seed: 42 for training feature synthesis; 20260924 for unseen test cases.

Existing datasets read but not modified:
- suppliers.csv
- products.csv
- purchase_orders.csv
- purchase_order_items.csv
- supplier_performance.csv
- market_prices.csv

The fraud datasets reuse the existing supplier and PO universe. Fraud labels are
derived from combinations of price, value, quantity, duplicate, split, timing,
and supplier-change signals rather than from a single threshold.
